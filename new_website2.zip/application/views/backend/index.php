<?php if($header) echo $header ;?>
<?php if($sidebar) echo $sidebar ;?>
<?php if($content) echo $content ;?>
<?php if($footer) echo $footer ;?>