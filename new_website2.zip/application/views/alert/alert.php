<div class="alert alert-<?= $flag?> margin-bottom-10">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
<?php if($flag == 'success'){ ?><i class="fa fa-check-circle-o fa-lg"></i><?php } ?> <?= $message?> </div>
