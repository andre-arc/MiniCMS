<footer class="default-footer">
<!--
					<div class="top padding paddv-60">
						<div class="container">
							<div class="row">
								<div class="col-md-3">
								</div>
								<div class="col-md-3">
									<div class="widget recent-tweets">
										<h2 class="widget-title">Recent Tweets</h2>
										<div class="twitie"></div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="widget tags-cloud">
										<h2 class="widget-title">Tags</h2>
										<ul>
											<li><a href="#">Lorem</a></li>
											<li><a href="#">ipsum</a></li>
											<li><a href="#">dolor</a></li>
											<li><a href="#">amet</a></li>
											<li><a href="#">nopri</a></li>
											<li><a href="#">modoagam</a></li>
											<li><a href="#">facer</a></li>
											<li><a href="#">timeam</a></li>
											<li><a href="#">adolesce</a></li>
											<li><a href="#">laudemne</a></li>
											<li><a href="#">partem</a></li>
											<li><a href="#">amet</a></li>
											<li><a href="#">nopri</a></li>
											<li><a href="#">modoagam</a></li>
											<li><a href="#">facer</a></li>
											<li><a href="#">timeam</a></li>
											<li><a href="#">adolesce</a></li>
										</ul>
									</div>
								</div>
								<div class="col-md-3">
									<div class="widget widget-newsletter">
										<h2 class="widget-title">News Letter</h2>
										<div class="content">
											<p>Lorem ipsum dolor sit amet, nopri modo agam face.</p>
											<form action="#" method="get" accept-charset="utf-8">
												<input type="text" value="" placeholder="Email address">
												<input type="submit" value="Subscribe">
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
-->
					<div class="bottom">
						<div class="container">
							<div class="col-md-8">
								<p class="copyrights">Copyright: <span>2017 DreanLab.com</span></p>
							</div>
							<div class="col-md-4">
								<ul class="social">
									<li><a href="#" data-toggle="tooltip" data-placement="top" title="Facebook">
										<i class="fa fa-facebook"></i>
									</a></li>
									<li><a href="#" data-toggle="tooltip" data-placement="top" title="Twitter">
										<i class="fa fa-twitter"></i>
									</a></li>
									<li><a href="#" data-toggle="tooltip" data-placement="top" title="Google Plus">
										<i class="fa fa-google-plus"></i>
									</a></li>
								</ul>
							</div>
						</div>	
					</div>
				</footer>
			</div>
			<!-- /Wrapper -->

	</div><!-- End Site Container -->

		<!-- pageload-overlay -->
	<div id="loader" class="pageload-overlay" data-opening="M 0,0 80,-10 80,60 0,70 0,0" data-closing="M 0,-10 80,-20 80,-10 0,0 0,-10">
		<svg xmlns="http://www.w3.org/2000/svg" width="0%" height="0%" viewBox="0 0 80 60" preserveAspectRatio="none">
			<path d="M 0,70 80,60 80,80 0,80 0,70"/>
		</svg>
	</div>
	<!-- /pageload-overlay -->

	<!-- jQuery  -->
	<script type="text/javascript" src="<?php echo base_url('assets/'.$this->template);?>/plugins/jquery/dist/jquery.min.js"></script>

	<?= $js ?>

</body>

</html>