<?php if (!defined('BASEPATH')) exit ('Hacking Attempt : Keluar dari sistem'); ?>
<?php if($header) echo $header ;?>
<?php if($content) echo $content ;?>
<?php if($footer) echo $footer ;?>