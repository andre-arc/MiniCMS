CKEDITOR.plugins.setLang('videoembed', 'en', {
    title: 'Insert video',
    button: 'Video Embedded',
    onlytxt: 'Youtube, Vimeo & Dailymotion URLs only',
    validatetxt: 'URL field should not be empty!',
    input_css: 'Custom CSS class name :'
});

